// Products data
const products = [
    {
        id: 1,
        name: "Traditional Silk Saree",
        price: "€109.99",
        image: "img/koskii-ranipink-zariwork-artsilk-designer-saree-saus0039010_ranipink_1_1.webp",
        description: "Elegant silk saree with traditional Tamil motifs",
        category: "traditional"
    },
    {
        id: 2,
        name: "Kanchipuram Silk",
        price: "€129.99",
        image: "img/koskii-copper-zariwork-softsilk-designer-saree-saus0039230_copper_1_1.webp",
        description: "Premium Kanchipuram silk with golden zari work",
        category: "silk"
    },
    {
        id: 3,
        name: "Rani Pink",
        price: "€219.99",
        image: "img/koskii-ranipink-zariwork-artsilk-designer-saree-saus0039002_ranipink_1_1.webp",
        description: "Exquisite bridal saree with intricate embroidery",
        category: "Silk"
    },
    {
        id: 4,
        name: "Rani Pink Embroidered Georgette Saree",
        price: "€279.99",
        image: "img/SAUS0039105_RANI_PINK_6.webp",
        description: "Elegant rani pink georgette saree with gold embroidery and sequin details",
        category: "bridal"
    },
    {
        id: 5,
        name: "Onion Pink Threadwork Tissue Saree",
        price: "€199.99",
        image: "img/koskii-onionpink-threadwork-tissue-designer-saree-saus0038899_onionpink_1_5_00d2b205-760d-4940-adea-d27258dd55c5.webp",
        description: "Vibrant colors perfect for celebrations",
        category: "traditional"
    },
    {
        id: 6,
        name: "Maroon Premium Saree",
        price: "€599.99",
        image: "img/koskii-maroon-zariwork-softsilk-designer-saree-saus0038815_maroon_1_10.webp",
        description: "Luxury bridal wear with premium embellishments",
        category: "bridal"
    }
];

// Cart state
let cart = [];

// Navigation
function showSection(sectionId) {
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(sectionId).classList.add('active');

    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${sectionId}`) {
            link.classList.add('active');
        }
    });
}

// Initialize navigation
document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const sectionId = link.getAttribute('href').substring(1);
        showSection(sectionId);
    });
});

// Cart button
document.getElementById('cartButton').addEventListener('click', () => {
    showSection('cart');
});
// Product rendering
function createProductCard(product) {
    return `
        <div class="product-card animate-fade-in">
            <div class="product-image">
                <img src="${product.image}" alt="${product.name}">
            </div>
            <div class="product-details">
                <h3 class="product-title">${product.name}</h3>
                <p class="product-description">${product.description}</p>
                <div class="product-actions">
                    <span class="product-price">${product.price}</span>
                    <button class="btn-primary" onclick="addToCart(${product.id})">
                        Add to Cart
                    </button>
                </div>
            </div>
        </div>
    `;
}
// Initialize featured products
const featuredProducts = document.getElementById('featuredProducts');
if (featuredProducts) {
    featuredProducts.innerHTML = products.slice(0, 3).map(createProductCard).join('');
}

// Initialize collections
const collectionsProducts = document.getElementById('collectionsProducts');
if (collectionsProducts) {
    collectionsProducts.innerHTML = products.map(createProductCard).join('');
}
// filtering
document.querySelectorAll('.filter-btn').forEach(button => {
    button.addEventListener('click', () => {
        const category = button.dataset.category;

        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        button.classList.add('active');

        const filteredProducts = category === 'all'
            ? products
            : products.filter(product => product.category === category);

        collectionsProducts.innerHTML = filteredProducts.map(createProductCard).join('');
    });
});

function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    const existingItem = cart.find(item => item.id === productId);

    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({ ...product, quantity: 1 });
    }

    updateCart();
}
function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    updateCart();
}

function updateQuantity(productId, delta) {
    const item = cart.find(item => item.id === productId);
    if (item) {
        item.quantity = Math.max(0, item.quantity + delta);
        if (item.quantity === 0) {
            removeFromCart(productId);
        } else {
            updateCart();
        }
    }
}

function updateCart() {
    const cartItems = document.getElementById('cartItems');
    const subtotalElement = document.getElementById('subtotal');
    const totalElement = document.getElementById('total');

    if (cart.length === 0) {
        cartItems.innerHTML = `
            <div class="empty-cart">
                <p>Your cart is empty</p>
                <button class="btn-primary" onclick="showSection('collections')">
                    Browse Collections
                </button>
            </div>
        `;
        subtotalElement.textContent = '€0.00';
        totalElement.textContent = '€0.00';
        return;
    }

    cartItems.innerHTML = cart.map(item => `
        <div class="cart-item">
            <div class="cart-item-image">
                <img src="${item.image}" alt="${item.name}">
            </div>
            <div class="cart-item-details">
                <h3 class="cart-item-title">${item.name}</h3>
                <p class="cart-item-price">${item.price}</p>
                <div class="quantity-controls">
                    <button class="quantity-btn" onclick="updateQuantity(${item.id}, -1)">-</button>
                    <span>${item.quantity}</span>
                    <button class="quantity-btn" onclick="updateQuantity(${item.id}, 1)">+</button>
                    <button class="btn-primary" onclick="removeFromCart(${item.id})">Remove</button>
                </div>
            </div>
        </div>
    `).join('');

    const total = cart.reduce((sum, item) => {
        const price = parseFloat(item.price.replace('€', ''));
        return sum + price * item.quantity;
    }, 0);

    subtotalElement.textContent = `€${total.toFixed(2)}`;
    totalElement.textContent = `€${total.toFixed(2)}`;
}

// Checkout process
document.getElementById('checkoutButton').addEventListener('click', () => {
    document.getElementById('checkoutSection').style.display = 'none';
    document.getElementById('paymentSection').classList.remove('hidden');
});

document.getElementById('payButton').addEventListener('click', () => {
    const paymentMethod = document.querySelector('input[name="payment"]:checked');
    if (!paymentMethod) {
        alert('Please select a payment method');
        return;
    }
    // Simulate payment processing
    alert('Payment successful! Thank you for your purchase.');
    cart = [];
    updateCart();
    document.getElementById('checkoutSection').style.display = 'block';
    document.getElementById('paymentSection').classList.add('hidden');
});

// Scroll animations for About section
function handleScrollAnimations() {
    const aboutHeader = document.querySelector('.about-header');
    const aboutCards = document.querySelectorAll('.about-card');

    if (aboutHeader && isElementInViewport(aboutHeader)) {
        aboutHeader.classList.add('visible');
    }
    aboutCards.forEach((card, index) => {
        if (isElementInViewport(card)) {
            // Stagger the animations
            setTimeout(() => {
                card.classList.add('visible');
            }, index * 200);
        }
    });
}
function isElementInViewport(el) {
    const rect = el.getBoundingClientRect();
    return (
        rect.top <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.bottom >= 0
    );
}

window.addEventListener('load', handleScrollAnimations);
window.addEventListener('scroll', handleScrollAnimations);
// Initialize cart
updateCart();
// Show home section by default
showSection('home');